<?
$sSectionName = "Вакансии";
$arDirProperties = array(
);
?>