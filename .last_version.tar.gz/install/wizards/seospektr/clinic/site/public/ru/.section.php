<?
$sSectionName="Главная";
?>