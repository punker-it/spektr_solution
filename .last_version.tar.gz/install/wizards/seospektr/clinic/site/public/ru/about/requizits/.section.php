<?
$sSectionName = "Реквизиты";
$arDirProperties = array(
);
?>