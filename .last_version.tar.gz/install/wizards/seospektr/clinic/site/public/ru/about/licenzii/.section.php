<?
$sSectionName = "Лицензии";
$arDirProperties = array(
);
?>