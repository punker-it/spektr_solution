<?
$sSectionName = "История";
$arDirProperties = array(
);
?>