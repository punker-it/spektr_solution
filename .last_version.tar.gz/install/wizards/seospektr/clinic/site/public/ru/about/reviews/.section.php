<?
$sSectionName = "Отзывы";
$arDirProperties = array(
);
?>