<?
$MESS ['DOWNLOAD'] = "Скачать";
?>