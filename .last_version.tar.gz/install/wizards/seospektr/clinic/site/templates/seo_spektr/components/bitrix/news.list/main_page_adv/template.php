<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(true);
?>

<div class="row">
	<?foreach($arResult["ITEMS"] as $arItem){?>
		<?
		$this->AddEditAction($arItem['ID'], $arItem['EDIT_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_EDIT"));
		$this->AddDeleteAction($arItem['ID'], $arItem['DELETE_LINK'], CIBlock::GetArrayByID($arItem["IBLOCK_ID"], "ELEMENT_DELETE"), array("CONFIRM" => GetMessage('CT_BNL_ELEMENT_DELETE_CONFIRM')));
		?>
		<?if($arItem["NAME"]){?>
			<div class="col-md-4">
		      <div class="item_advant" id="<?=$this->GetEditAreaId($arItem['ID']);?>">
		        <div class="title"><?=$arItem["NAME"]?></div>
		        <?if($arItem["PREVIEW_TEXT"]){?>
		        	<div class="description"><?=$arItem["PREVIEW_TEXT"]?></div>
		        <?}?>
				<?if($arItem["PROPERTIES"]["LINK"]["VALUE"]){?>
			        <div class="button">
			          <?=$arItem["PROPERTIES"]["LINK"]["~VALUE"]["TEXT"]?>
			        </div>
		        <?}elseif($arItem["PROPERTIES"]["BUTTON_FORM"]["VALUE"]){?>
		        	<div class="button">
			          <?=$arItem["PROPERTIES"]["BUTTON_FORM"]["~VALUE"]["TEXT"]?>
			        </div>
		        <?}?>
		      </div>
		    </div>
	    <?}?>
	<?}?>
</div>
